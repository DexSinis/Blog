//
//  Restaurant.swift
//  FoodPin
//
//  Created by 000 on 15/9/11.
//  Copyright (c) 2015年 000. All rights reserved.
//

import UIKit

class Restaurant: NSObject {
     var name:String!
     var type:String!
     var location:String!
     var image:UIImage!
     var isVisited:NSNumber!
}
