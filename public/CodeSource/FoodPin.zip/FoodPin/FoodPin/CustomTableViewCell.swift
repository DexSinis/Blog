//
//  CustomTableViewCell.swift
//  FoodPin
//
//  Created by 000 on 15/9/10.
//  Copyright (c) 2015年 000. All rights reserved.
//
import UIKit

class CustomTableViewCell: UITableViewCell {

    var nameLabel: UILabel!
    var locationLabel: UILabel!
    var typeLabel: UILabel!
    var thumbnailImageView: UIImageView!
    let HMStatusCellInset:CGFloat! = 10.0
    
//    var restaurant:Restaurant!
   
//    var restaurant:Restaurant!
//    {
//        get
//        {
//            return self.restaurant
//        }set
//        {
//           // self.restaurant = newValue
//            self.setNewRestaurant(newValue)
//        }
//    }
    


    var restaurant:Restaurant!
  {

       didSet
        {
            setView(restaurant)
        }
  }


    func updateHeightCell()
    {
        self.thumbnailImageView.image = self.restaurant.image
        self.nameLabel.text = self.restaurant.name
    }
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected statex
    }

    override init(style: UITableViewCellStyle, reuseIdentifier: String?)
    {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        self.thumbnailImageView  = UIImageView()
        self.contentView.addSubview(self.thumbnailImageView)
        self.nameLabel  = UILabel()
        self.nameLabel.numberOfLines = 0
        self.contentView.addSubview(self.nameLabel)
//        [self.contentView addSubview:self.lblBody];
        //布局
//        self.setView(self.restaurant)
    }
    
    required init(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    //布局
    func setView(restaurant:Restaurant)
    {
        let superview = self
        
//        OC
//        view1.mas_makeConstraints { make in
//            make.top.greaterThanOrEqualTo()(superview.mas_top).offset()(10)
//            make.left.equalTo()(superview.mas_left).offset()(10)
//            make.bottom.equalTo()(view3.mas_top).offset()(-10)
//            make.right.equalTo()(view2.mas_left).offset()(-10)
//            make.width.equalTo()(view2.mas_width)
//            make.height.equalTo()(view2.mas_height)
//            make.height.equalTo()(view3.mas_height)
//        }
        
        self.thumbnailImageView.mas_makeConstraints { make in
            make.left.equalTo()(superview.mas_top).offset()(10)
            make.top.equalTo()(superview.mas_top).offset()(10)
            make.width.equalTo()(35)
            make.height.equalTo()(35)
        }
        self.nameLabel.mas_makeConstraints { make in
            make.left.equalTo()(self.thumbnailImageView.mas_right).offset()(10)
            make.top.equalTo()(self.thumbnailImageView)
            make.width.equalTo()(superview.frame.width - self.thumbnailImageView.frame.width - 10)
            make.height.equalTo()(40)
//            make.bottom.equalTo()(-20);
        }
        // 1.头像
//        var thumbnailImageX:CGFloat = HMStatusCellInset;
//        var thumbnailImageY:CGFloat = HMStatusCellInset;
//        var thumbnailImageW:CGFloat = 35;
//        var thumbnailImageH:CGFloat = 35;
//         self.thumbnailImageView  = UIImageView(frame: CGRectMake(thumbnailImageX, thumbnailImageY, thumbnailImageW, thumbnailImageH))
//         self.contentView.addSubview(self.thumbnailImageView)
        
//        // 2.昵称
//        
//        var nameX:CGFloat =  CGFloat(Float(CGRectGetMaxX(self.thumbnailImageView.frame))+Float(HMStatusCellInset));
//        var nameY:CGFloat = thumbnailImageX;
//        
//        
//        var maxW:CGFloat = CGFloat(UIScreen.mainScreen().bounds.width)
//        //CGFloat(320.0 - Float(CGRectGetMaxX(self.thumbnailImageView.frame)) - (Float(HMStatusCellInset) * 2));
//        var maxSize:CGSize = CGSizeMake(maxW, CGFloat(MAXFLOAT));
//        var option = NSStringDrawingOptions.UsesLineFragmentOrigin
//        var attributes:NSDictionary = NSDictionary(object:UIFont.systemFontOfSize(13.0), forKey: NSFontAttributeName)
//        var nameSize:CGSize = restaurant.name.boundingRectWithSize(maxSize, options: option, attributes: attributes as [NSObject : AnyObject], context: nil).size
//        self.nameLabel = UILabel(frame: CGRectMake(nameX, nameY,nameSize.width,nameSize.height))
//        self.nameLabel.font = UIFont.systemFontOfSize(13.0)
//        self.contentView.addSubview(self.nameLabel)
//        
//        
//        // 3.地址
//        var locationX:CGFloat =  CGFloat(Float(CGRectGetMaxX(self.thumbnailImageView.frame))+Float(HMStatusCellInset));
//        var locationY:CGFloat = thumbnailImageX;
//        
//        
//        var locationW:CGFloat = CGFloat(UIScreen.mainScreen().bounds.width)
//        //CGFloat(320.0 - Float(CGRectGetMaxX(self.thumbnailImageView.frame)) - (Float(HMStatusCellInset) * 2));
//        var maxlocationSize:CGSize = CGSizeMake(maxW, CGFloat(MAXFLOAT));
//        var locationoption = NSStringDrawingOptions.UsesLineFragmentOrigin
//        var locationattributes:NSDictionary = NSDictionary(object:UIFont.systemFontOfSize(13.0), forKey: NSFontAttributeName)
//        var locationSize:CGSize = restaurant.name.boundingRectWithSize(maxlocationSize, options: locationoption, attributes: locationattributes as [NSObject : AnyObject], context: nil).size
//        self.locationLabel = UILabel(frame: CGRectMake(nameX, nameY,nameSize.width,nameSize.height))
//        self.locationLabel.font = UIFont.systemFontOfSize(13.0)
//        self.contentView.addSubview(self.locationLabel)
//        
        
        

        //        CGSize nameSize = [comment.user.name sizeWithFont:HMStatusOrginalNameFont];
        //        self.nameCommentFrame = (CGRect){{nameX, nameY}, nameSize};
        //
        //
        //
        //        // 3.正文
        //        CGFloat textX = nameX;
        //        CGFloat textY = CGRectGetMaxY(self.nameCommentFrame) + HMStatusCellInset ;
        //        //    CGFloat maxW = HMScreenW - 2 * textX;
        //        CGFloat maxW = HMScreenW - CGRectGetMaxX(self.iconCommentFrame)- HMStatusCellInset * 2;
        //        CGSize maxSize = CGSizeMake(maxW, MAXFLOAT);
        //
        //        // 删掉最前面的昵称
        //        NSMutableAttributedString *text = [[NSMutableAttributedString alloc] initWithAttributedString:comment.attributedText];
        //
        //
        //        CGSize textSize = [text boundingRectWithSize:maxSize options:NSStringDrawingUsesLineFragmentOrigin context:nil].size;
        //        self.textCommentFrame = (CGRect){{textX, textY}, textSize};
        //
        //        //    NSMutableParagraphStyle *paragraphStyle = [[NSMutableParagraphStyle alloc]init];
        //        //    paragraphStyle.lineBreakMode = NSLineBreakByWordWrapping;
        //        //    NSDictionary *attributes = @{NSFontAttributeName:[UIFont systemFontOfSize:13.0f], NSParagraphStyleAttributeName:paragraphStyle.copy};
        //        //    CGSize textSize = [comment.text boundingRectWithSize:maxSize options:NSStringDrawingUsesLineFragmentOrigin attributes:attributes context:nil].size;
        //        //    self.textCommentFrame = (CGRect){{textX, textY}, textSize};
        //
        //        // 4.配图相册
        //        CGFloat h = 0;
        //
        //        h = CGRectGetMaxY(self.textCommentFrame) + HMStatusCellInset;
        //        
        //        
        //        // 自己
        //        CGFloat x = 0;
        //        CGFloat y = 0;
        //        CGFloat w = HMScreenW;
        //        self.frame = CGRectMake(x, y, w, h);
    }
  
    //赋值
    override func layoutSubviews()
    {
        super.layoutSubviews()
        if((restaurant) != nil)
        {
            thumbnailImageView.image = restaurant.image
            nameLabel.text = restaurant.name
        }
        
    }

}
