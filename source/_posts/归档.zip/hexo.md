title: Hexo
---
77  nvm -help
78  brew install node
79  ruby -e "$(curl -fsSL https://raw.github.com/Homebrew/homebrew/go/install)”
80  ruby -e "$(curl -fsSL https://raw.github.com/Homebrew/homebrew/go/install)”
81  ruby -e "$(curl -fsSL https://raw.github.com/Homebrew/homebrew/go/install)"
82  ruby -e "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/master/install)"
83  git clone git://github.com/creationix/nvm.git ~/nvm
84  nvm
85   cd ~/Users/a000/nvm
86  ls
87  cd /Users/a000/nvm
88  ls
89  cd ../
90  "/Users/a000/nvm/nvm.sh" >> ~/.bash_profile
91  vi ~/.bash_profile
92  vi ~/.bash_profile
93  nvm
94  vi ~/.bash_profile
95  vi ~/.bash_profile
96  vi ~/.bash_profile
97  cat  ~/.bash_profile
98  nvm
99  echo ". ~/.nvm/nvm.sh" >> ~/.bash_profile
100  nvm
101  cat  ~/.bash_profile
102  cd ~/.nvm/
103  cd ~/nvm/
104  ls
105  vi ~/.bash_profile
106  nvm
107  cat  ~/.bash_profile
108  cd ~/nvm/nvm.sh
109  cd ~/nvm/
110  ls
111  vi ~/.bash_profile
112  cat  ~/.bash_profile
113  nvm
114  brew install node
115  brew link node
116  sudo brew install node
117  brew --help
118  /Users/a000/Desktop/uninstall_node.sh 
119  git clone git://github.com/creationix/nvm.git ~/nvm
120  echo ". ~/.nvm/nvm.sh" >> ~/.bash_profile
121  vi ~/.bash_profile
122  vi ~/.bash_profile
123  nvm
124  vi ~/.bash_profile
125  nvm
126  cd ~/Users
127  cd nvm
128  ls
129  cd ../
130  pwd
131  cd nvm
132  l
133  ls
134  pwd
135  nvm
136  cd nvm
137  ls
138  pwd
139  source ~/nvm/nvm.sh/nvm.sh
140  source ~/nvm/nvm.sh
141  vi ~/.bash_profile
142  nvm
143  nvm install v0.8.14
144  nvm install v0.10.28
145  vi ~/.bash_profile
146  nvm
147  nvm
148  vi ~/.bash_profile
149  nvm
150  source ~/nvm/nvm.sh
151  nvm
152  source ~/nvm/nvm.sh
153  source ~/.nvm/nvm.sh
154  vi ~/.bash_profile
155  vi ~/.bash_profile
156  nvm
157  vi ~/.bash_profile
158  vi ~/.bash_profile
159  nvm
160  nvm
161  echo ". ~/.nvm/nvm.sh" >> ~/.bash_profile
162  vi ~/.bash_profile
163  cat ~/.bash_profile 
164  nvm
165  nvm
166  source ~/nvm/nvm.sh/nvm.sh
167  source ~/nvm/nvm.sh
168  nvm
169  nvm install v0.10.28
170  nvm use  v0.10.28
171  nvm alias default v0.10.28
172  npm install -g hexo
173  cat ~/.bash_profile 
174  nvm
175  nvm
176  npm install -g hexo@2.6.1
177  nvm
178  sudo root
179  su root
180  hexo
181  cd IDE/
182  ls
183  cd XcodeP/
184  ls
185  cd nodejs/
186  ls
187  cd hexo
188  hexo init
189  ls
190  vi _config.yml 
191  cat _config.yml 
192  vi _config.yml 
193  hexo g
194  hexo generate
195  ls
196  sudo hexo init blog
197  ls
198  cd ../
199  l
200  ls
201  cd hexo/
202  ls
203  hexo init Blog
204  ls
205  npm install
206  cd ../
207  cd hexo
208  ls
209  npm install
210  ls
211  hexo genrate
212  ls
213  cd ../
214  ls
215  cd ../
216  ls
217  cd nodejs
218  ls
219  cd hexo/
220  ls
221  cd ../
222  ls
223  mkdir Blog
224  ls
225  rm -rf hexo
226  ls
227  hexo init
228  ls
229  npm install
230  hexo g
231  hexo generate
232  rm -rf Blog
233  ls
234  cd ../
235  ls
236  cd ../
237  cd nodejs
238  mkdir hexo
239  ls
240  cd hexo
241  ls
242  mkdir hexo
243  hexo init
244  npm install
245  hexo generate
246  s
247  ls
248  hexo generate
249  vi _config.yml 
250  hexo generate
251  vi _config.yml 
252  hexo generate
253  vi _config.yml 
254  vi _config.yml 
255  hexo generate
256  hexo n
257  vi _config.yml 
258  hexo new
259  cd ../
260  ls
261  cd hexo
262  ls
263  cd hex
264  cd hexo
265  ls
266  hexo new redme.txt
267  ls
268  hexo help
269  help --new
270  hexo help new
271  hexo server
272  hexo server
273  hexo help server
274  cd ../
275  ls
276  cd ../
277  rm -rf hexo
278  l
279  ld
280  ls
281  mkdir Hexo
282  cd Hexo/
283  ls
284  hexo init
285  hexo g
286  hexo s
287  hexo clean
288  hexo clean
289  hexo g
290  hexo s
291  git clone https://github.com/cnfeat/cnfeat.git themes/jacman
292  $ git clone https://github.com/A-limon/pacman.git themes/pacman
293  git clone https://github.com/A-limon/pacman.git themes/pacman
294  cd themes
295  ls
296  cd pacman/
297  ls
298  git pull
299  vi _config.yml 
300  ls
301  vi _config.yml 
302  hexo g
303  ls
304  cd ../
305  ls
306  cd ../
307  ls
308  cd ../
309  cd Hexo/
310   hexo g
311  hexo s
312  cd ../
313  ls
314  rm -rf Hexo/
315  ls
316  mkdir Hexo
317  cd Hexo/
318  ls
319  hexo init
320  hexo g
321  hexo s
322  npm install
323  ls
324  hexo g
325  cd ../
326  rm -rf Hexo/
327  mkdir Hexo
328  cd Hexo/
329  hexo init
330  ls
331  hexo g
332  ls
333  hexo s
334  vi _config.yml 
335  hexo g
336  hexo s
337  hexo d
338  vi _config.yml 
339  ls
340  npm install
341  hexo s
342  ls
343  cd node_modules/
344  ls
345  hexo clean
346  cd ../
347  ls
348  hexo clean
349  hexo g
350  ls
351  vi _config.yml 
352  ls
353  cd node_modules/
354  ls
355  cd ..
356  ls
357  ls
358  cat package.json 
359  cd ..
360  hexo generate
361  ls
362  cd Hexo/
363  ls
364  cat _config.yml 
365  vi _config.yml 
366  ls
367  cd node_modules/
368  ls
369  cd ../
370  ls
371  cd node_modules/
372  ls
373  cd ../
374  ls
375  hexo s
376  hexo g
377  cd ../
378  ls
379  mkdir Bolg
380  ls
381  cd Bolg/
382  ls
383  hexo init
384  ls
385  hexo g
386  hexo s
387  vim package.json 
388  npm install -g hexo-cli
389  su root
390  su root
391  cd IDE/
392  ls
393  rm -rf Bolg/
394  ls
395  mkdir Blog
396  ls
397  cd Blog/
398  hexo init
399  npm install
400  cd ../
401  cd ~
402  ls
403  cd Id
404  cd IDE/
405  ls
406  cd Hexo/
407  sudo npm install
408  ls
409  cd node_modules/
410  ls
411  cd ../
412  ls
413  cd ../
414  cd Blog/
415  ls
416  cd node_modules/
417  ls
418  cd ../
419  ls
420  sudo hexo clean
421  sudo $ npm install hexo --no-optional
422  ls
423  sudo hexo clean
424  ls
425  ls
426  hexo s
427  sudo hexo g
428  hexo s
429  cd ../
430  ls
431  ls
432  rm -rf Blog/
433  sudo rm -rf Blog/
434  ls
435  mkdir Blog
436  cd Blog/
437  ls
438  hexo init
439  ls
440  hexo g
441   npm install hexo --no-optional
442  hexo g
443  hexo s
444  sudo hexo s
445  hexo g
446  ls
447  hexo s
448  hexo server
449  npm install
450  hexo g
451  hexo s
452  hexo new index.html
453  hexo g
454  hexo s
455  ls
456  cd public/
457  ls
458  ../
459  pwd
460  ./
461  ls
462  open .
463  cd ../
464  ls
465  vi _config.yml 
466  ls
467  hexo g
468  vi _config.yml 
469  hexo g
470  vi _config.yml 
471  hexo clean
472  ls
473  vi _config.yml 
474  hexo g
475  vi
476  vi _config.yml 
477  hexo g
478  vi _config.yml 
479  hexo g
480  vi _config.yml 
481  vi _config.yml 
482  vi _config.yml 
483  hexo g
484  vi _config.yml 
485  hexo g
486  cat _config.yml 
487  vi _config.yml 
488  hexo g
489  vi _config.yml 
490  hexo g
491  vi _config.yml 
492  hexo g
493  vi _config.yml 
494  hexo g
495  git deploy
496  hexo deploy
497  npm install hexo-deployer-git --save
498  cd IDE/Blog/
499  ls
500  sudo npm install hexo-deployer-git --save
501   npm install -g cnpm --registry=https://registry.npm.taobao.org
502  cnpm
503  cd IDE/
504  cd Blog/
505  sudo cnpm install hexo-deployer-git --save
506  hexo d
507  hexo g
508  vi _config.yml 
509  hexo d
510  vi _config.yml 
511  hexo d
512  hexo g
513  hexo d
514  hexo clean
515  hexo g
516  hexo d
517  ls
518  cat package.json 
519  hexo server
520  vi _config.yml 
521  hexo d
522  vi _config.yml 
523  hexo g
524  hexo d
525  hexo d
526  ls
527  hexo d
528  hexo g
529  hexo d
530  history
531  ls
532  cd public/
533  ls
534  open .
535  hexo g
536  hexo g
537  hexo d
538  vi index.html 
539  vi index.html 
540  hexo g
541  hexo g
542  hexo d
543  vi index.html 
544  vi index.html 
545  cat index.html
546  hexo d
547  vi index.html 
548  hexo d
549  cat index.html
550  touch hexo
551  ls
552  hexo d
553  cd ../
554  ls
555  cd _config.yml 
556  vi _config.yml 
557  cd public/
558  ls
559  cd ../
560  hexo new hexo
561  cd source/
562  ls
563  cd _posts/
564  ls
565  vim hexo
566  hexo d
567  hexo g
568  hexo d
569  ls
570  vi hexo
571  vi hexo.md
572  hexo g
573  hexo d
574  hexo g
575  hexo d

## Quick Start

### 添加样式和评论UA

``` bash
   <script type="text/javascript">
  var duoshuoQuery = {short_name:"<%= theme.duoshuo_shortname %>"};
  (function() {
    var ds = document.createElement('script');
    ds.type = 'text/javascript';ds.async = true;
    ds.src = '//dexsinister.github.io/embed.js';
    ds.charset = 'UTF-8';
    (document.getElementsByTagName('head')[0]
    || document.getElementsByTagName('body')[0]).appendChild(ds);
  })();
  </script>

  修改 embed.js 中的id

  public 生成的部署文件

  themes 需要安装的样式
```

More info: [ClickHere](https://github.com/wsgzao/duoshuo-mod)

### Run server

``` bash
/Users/a000/IDE/Blog/themes/jacman/_config.yml

duoshuo_shortname: dexsinister

apple_icon: favicon.ico

```

More info: [ClickHere](http://wsgzao.github.io/post/duoshuo/)

### more files

``` bash
   https://github.com/DexSinister/DexSinister.github.io
   http://dexsinister.github.io/
   http://myhloli.com/duoshuo-ua-and-admin-tab.html
```
